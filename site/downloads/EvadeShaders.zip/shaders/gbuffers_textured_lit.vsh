#version 330 compatibility
/* Evade Shaders - gbuffers_textured_lit: see program/gbuffers_main.glsl */
#define VERTEX
#define PROG_TEXTURED
#include "/program/gbuffers_main.glsl"
