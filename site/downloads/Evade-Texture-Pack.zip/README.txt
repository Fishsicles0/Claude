Evade Texture Pack v1.0 for Minecraft 1.21.11 (resource pack format 75).
Optional companion to Evade Client: black & red menus, hotbar and tooltips, a sharp crosshair, low fire,
red sword blades and pearls, and the Evade logo on the title screen.

Install: Options > Resource Packs > Open Pack Folder, drop this zip in, then move it to the right-hand list.
Made from Minecraft's own textures, recoloured. Not affiliated with Mojang or Microsoft.
